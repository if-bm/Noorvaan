
document.addEventListener('DOMContentLoaded', () => {
  const yearEl = document.getElementById('year');
  if (yearEl) yearEl.textContent = new Date().getFullYear();

  if (document.body.dataset.page === 'shop') {
    fetch('data/products.json')
      .then(r => r.json())
      .then(items => {
        const grid = document.getElementById('product-grid');
        grid.innerHTML = '';
        items.forEach(p => {
          const div = document.createElement('div');
          div.className = 'card';
          div.innerHTML = `
            <img src="${p.image}" alt="${p.name} product photo">
            <div class="pad">
              <h3>${p.name}</h3>
              <p class="price">${p.price} · ${p.weight}</p>
              <p>${p.description}</p>
              <p><a class="btn" href="${p.stripe_link}" target="_blank" rel="noopener">Buy now</a></p>
            </div>`;
          grid.appendChild(div);
        });
      })
      .catch(() => {
        const grid = document.getElementById('product-grid');
        grid.innerHTML = '<p class="notice">Could not load products.</p>';
      });
  }
});
